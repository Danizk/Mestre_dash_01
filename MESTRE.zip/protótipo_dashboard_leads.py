# =========================================
# 📊 Protótipo de Dashboard de Leads (com Plotly Interativo)
# =========================================

import pandas as pd
import plotly.express as px
import gspread
from gspread_dataframe import get_as_dataframe
from oauth2client.service_account import ServiceAccountCredentials
import logging

logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')

def conectar_google_sheets(credentials_path, sheet_url, aba_nome):
    scopes = ['https://spreadsheets.google.com/feeds', 'https://www.googleapis.com/auth/drive']
    credentials = ServiceAccountCredentials.from_json_keyfile_name(credentials_path, scopes)
    gc = gspread.authorize(credentials)
    spreadsheet = gc.open_by_url(sheet_url)
    worksheet = spreadsheet.worksheet(aba_nome)
    df = get_as_dataframe(worksheet, evaluate_formulas=True)
    return df

def gerar_dashboards_interativos(df):
    # Leads por origem
    fig = px.bar(df['lead_origem'].value_counts().head(10).reset_index(),
                 x='lead_origem', y='count',
                 labels={'lead_origem': 'Origem', 'count': 'Quantidade'},
                 title='Leads por Origem')
    fig.show()

    # Leads quentes vs frios
    fig2 = px.pie(df, names='lead_calor', title='Distribuição de Leads Quente/Frio',
                  color_discrete_sequence=px.colors.sequential.RdBu)
    fig2.show()

    # Leads por dia da semana
    if 'dia_semana' in df.columns:
        fig3 = px.bar(df['dia_semana'].value_counts().reset_index(),
                      x='index', y='dia_semana',
                      labels={'index': 'Dia da Semana', 'dia_semana': 'Quantidade'},
                      title='Leads por Dia da Semana')
        fig3.show()

def main():
    try:
        credentials_path = r'C:/Users/Distritek/MESTRE/config/credentials.json'
        sheet_url = 'https://docs.google.com/spreadsheets/d/10UuE5rKRWVqBGeN9GQYjaoKazw1jiQWLbJB5FPlsTqU'
        aba_nome = 'CLEAN'
        df = conectar_google_sheets(credentials_path, sheet_url, aba_nome)
        gerar_dashboards_interativos(df)
    except Exception as e:
        logging.error(f'Erro: {e}')

if __name__ == "__main__":
    main()

