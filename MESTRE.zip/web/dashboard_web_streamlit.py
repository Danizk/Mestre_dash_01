# =========================================
# 🌐 Dashboard Web com Streamlit - Projeto MESTRE
# =========================================

import streamlit as st
import pandas as pd
import gspread
from gspread_dataframe import get_as_dataframe
from oauth2client.service_account import ServiceAccountCredentials

# Conectar ao Google Sheets
def conectar_google_sheets(credentials_path, sheet_url, aba_nome):
    scopes = ['https://spreadsheets.google.com/feeds', 'https://www.googleapis.com/auth/drive']
    credentials = ServiceAccountCredentials.from_json_keyfile_name(credentials_path, scopes)
    gc = gspread.authorize(credentials)
    spreadsheet = gc.open_by_url(sheet_url)
    worksheet = spreadsheet.worksheet(aba_nome)
    df = get_as_dataframe(worksheet, evaluate_formulas=True)
    return df

# Função principal
def main():
    st.set_page_config(page_title="Dashboard Imobiliária Mestre", layout="wide")
    st.title("🏡 Dashboard de Leads - Mestre Imóveis")

    credentials_path = r'C:/Users/Distritek/MESTRE/config/credentials.json'
    sheet_url = 'https://docs.google.com/spreadsheets/d/10UuE5rKRWVqBGeN9GQYjaoKazw1jiQWLbJB5FPlsTqU'
    aba_nome = 'CLEAN'
    
    df = conectar_google_sheets(credentials_path, sheet_url, aba_nome)
    
    st.subheader("Leads por Origem")
    st.bar_chart(df['lead_origem'].value_counts())

    st.subheader("Distribuição de Leads Quente/Frio")
    st.dataframe(df['lead_calor'].value_counts())

if __name__ == "__main__":
    main()